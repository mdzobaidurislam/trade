<div class="page_logo">
    <img src="<?php echo $site_info['logo']??""; ?>" alt="">
</div>