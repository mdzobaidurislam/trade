<?php include_once 'header.php'; ?>
<div class="container">
    <h1>Dashboard</h1>
    <p>Welcome to the admin dashboard!</p>
</div>

<?php include_once 'footer.php'; ?>