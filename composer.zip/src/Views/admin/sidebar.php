<aside class="sidebar">
    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link active" href="admin">Dashboard</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="admin/user/manage">Manage Users</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="admin/banner/manage">Manage Banner</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="admin/left_banner/manage">Left logo</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="admin/right_banner/manage">Right logo</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="admin/setting">Setting</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="admin/change_password">Change Password</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="admin/trade">Trade List</a>
        </li>
    </ul>
</aside>